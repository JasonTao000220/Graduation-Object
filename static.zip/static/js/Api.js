var urlHead = "http://";

var urlFoot = "localhost:8080";

var url = urlHead.toString() + urlFoot.toString();